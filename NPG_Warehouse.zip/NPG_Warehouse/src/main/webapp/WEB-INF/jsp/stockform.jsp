<%@ taglib uri="http://www.springframework.org/tags/form" prefix="form"%>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" %>
<% request.setCharacterEncoding("UTF-8"); %>

<!DOCTYPE html>
<html>
<head>
    <title>Add Stock</title>
</head>
<body>
    <h1>Add New Stock</h1>
    <form:form method="post" action="savestock">
        <table>
            <tr>
                <td>Stock ID: </td>
                <td><form:input path="stockID" /></td>
            </tr>
            <tr>
                <td>Name: </td>
                <td><form:input path="stockName" /></td>
            </tr>
            <tr>
                <td>Location: </td>
                <td><form:input path="stockLocation" /></td>
            </tr>
            <tr>
                <td>Remark: </td>
                <td><form:input path="stockRemark" /></td>
            </tr>
            <tr>
                <td>Method (P/S): </td>
                <td>
                    <form:select path="stockMethod">
                        <form:option value="P">P</form:option>
                        <form:option value="S">S</form:option>
                    </form:select>
                </td>
            </tr>
            <tr>
                <td>Category: </td>
                <td>
                    <form:select path="categoryID">
                        <form:options items="${categories}" />
                    </form:select>
                </td>
            </tr>
            <tr>
                <td>Unit: </td>
                <td>
                    <form:select path="unitID">
                        <form:options items="${units}" />
                    </form:select>
                </td>
            </tr>
            <tr>
                <td>Supplier: </td>
                <td>
                    <form:select path="supplierID">
                        <form:options items="${suppliers}" />
                    </form:select>
                </td>
            </tr>
            <tr>
                <td>Warehouse: </td>
                <td>
                    <form:select path="warehouseID">
                        <form:options items="${warehouses}" />
                    </form:select>
                </td>
            </tr>
            <tr>
                <td></td>
                <td><input type="submit" value="Save" /></td>
            </tr>
        </table>
    </form:form>
</body>
</html>