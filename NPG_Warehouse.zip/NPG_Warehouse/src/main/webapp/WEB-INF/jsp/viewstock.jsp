<%@ page contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Ngwe Pone Gyi</title>
    <link href="https://unpkg.com/lucide@latest" rel="stylesheet">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

       body {
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
            background-color: #f5f5f5;
            color: #333;
        }

        /* Header */
        .header {
            background: #ff5722;
            color: white;
            height: 80px;
            display: flex;
            align-items: center;
            padding: 0 32px;
            position: relative;
            z-index: 100;
        }

        .header-content {
            display: flex;
            align-items: center;
            gap: 16px;
            width: 100%;
        }

        .logo {
            width: 56px;
            height: 56px;
            background: #e0e0e0;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            flex-shrink: 0;
        }
        
        .logo img {
            width: 40px;
            height: 40px;
            border-radius: 50%;
        }

        .brand-name {
            font-size: 35px;
            font-weight: 600;
            letter-spacing: 1px;
            margin-left: 600px;
        }

        /* Layout */
        .container {
            display: flex;
            min-height: calc(100vh - 80px);
        }

        /* Sidebar */
        .sidebar {
            width: 240px;
            background: white;
            border-right: 1px solid #e0e0e0;
            padding: 16px;
            flex-shrink: 0;
        }

        .nav-menu {
            display: flex;
            flex-direction: column;
            gap: 4px;
        }

        .menu-item {
            display: flex;
            align-items: center;
            gap: 12px;
            padding: 10px 16px;
            text-decoration: none;
            color: #666;
            font-size: 14px;
            font-weight: 500;
            transition: all 0.2s ease;
            cursor: pointer;
            border: none;
            background: none;
            width: 100%;
            text-align: left;
            border-radius: 8px;
        }

        .menu-item:hover {
            background-color: #f8f9fa;
            color: #333;
        }

        .menu-item.active {
            background-color: #e3f2fd;
            color: #1976d2;
            border: 1px solid #bbdefb;
        }

        .menu-icon {
            width: 20px;
            height: 20px;
            display: flex;
            align-items: center;
            justify-content: center;
        }

        .logout-section {
            border-top: 1px solid #e0e0e0;
            margin-top: 250px;
            padding-top: 16px;
        }

        /* Main Content */
        .main-content {
            flex: 1;
            display: flex;
            flex-direction: column;
            background: #f8f9fa;
        }

        /* Top Bar */
        .top-bar {
            background: white;
            border-bottom: 1px solid #e0e0e0;
            padding: 16px 24px;
            display: flex;
            align-items: center;
            justify-content: space-between;
        }

        .search-container {
            flex: 1;
            max-width: 400px;
            position: relative;
        }

        .search-input {
            width: 100%;
            padding: 10px 16px 10px 40px;
            border: 1px solid #ddd;
            border-radius: 8px;
            font-size: 14px;
            outline: none;
            transition: all 0.2s ease;
            background: #f8f9fa;
        }

        .search-input:focus {
            border-color: #1976d2;
            background: white;
            box-shadow: 0 0 0 3px rgba(25, 118, 210, 0.1);
        }

        .search-icon {
            position: absolute;
            left: 12px;
            top: 50%;
            transform: translateY(-50%);
            color: #999;
        }

        .top-bar-actions {
            display: flex;
            align-items: center;
            gap: 16px;
        }

        .action-btn {
            width: 40px;
            height: 40px;
            border: none;
            background: none;
            border-radius: 8px;
            display: flex;
            align-items: center;
            justify-content: center;
            color: #666;
            cursor: pointer;
            transition: all 0.2s ease;
            position: relative;
        }

        .action-btn:hover {
            background-color: #f0f0f0;
            color: #333;
        }

        .notification-dot {
            position: absolute;
            top: 8px;
            right: 8px;
            width: 8px;
            height: 8px;
            background: #f44336;
            border-radius: 50%;
        }

        /* Content Area */
        .content-area {
            padding: 24px;
            flex: 1;
        }

        .content-header {
            display: flex;
            align-items: center;
            justify-content: space-between;
            margin-bottom: 24px;
        }

        .page-title {
            font-size: 24px;
            font-weight: 600;
            color: #333;
        }

        .add-btn {
            display: flex;
            align-items: center;
            gap: 8px;
            background: #1976d2;
            color: white;
            border: none;
            padding: 10px 16px;
            border-radius: 8px;
            font-size: 14px;
            font-weight: 500;
            cursor: pointer;
            transition: all 0.2s ease;
        }

        .add-btn:hover {
            background: #1565c0;
        }

        .stat-row {
            display: flex;
            justify-content: space-between;
            font-size: 14px;
            margin-bottom: 4px;
        }

        .stat-value {
            font-weight: 600;
        }

        .text-green {
            color: #4caf50;
        }

        /* Empty State */
        .empty-state {
            text-align: center;
            padding: 40px 20px;
            color: #999;
        }

        .empty-icon {
            font-size: 48px;
            margin-bottom: 16px;
            opacity: 0.5;
        }

        .empty-title {
            font-size: 18px;
            font-weight: 600;
            color: #666;
            margin-bottom: 8px;
            text-transform: capitalize;
        }

        .empty-description {
            color: #999;
            font-size: 14px;
        }

        /* Responsive */
        @media (max-width: 768px) {
            .container {
                flex-direction: column;
            }
            
            .sidebar {
                width: 100%;
                height: auto;
            }
            
            .customer-grid {
                grid-template-columns: 1fr;
            }
        }
    </style>
</head>
<body>
    <!-- Header -->
    <header class="header">
        <div class="header-content">
            <div class="logo">
                <img src="data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 100 100'%3E%3Ccircle cx='50' cy='50' r='45' fill='%23ff5722'/%3E%3Ctext x='50' y='60' text-anchor='middle' fill='white' font-size='40' font-weight='bold'%3EN%3C/text%3E%3C/svg%3E" alt="Logo">
            </div>
            <h1 class="brand-name">Ngwe Pone Gyi</h1>
        </div>
    </header>

    <div class="container">
        <!-- Sidebar -->
        <aside class="sidebar">
            <nav class="nav-menu">
                <a href="dashboard" class="menu-item" onclick="setActiveMenu('dashboard')">
                    <i data-lucide="home" class="menu-icon"></i>
                    <span>Dashboard</span>
                </a>
                <a href="viewstock" class="menu-item active" onclick="setActiveMenu('stocks')">
                    <i data-lucide="package" class="menu-icon"></i>
                    <span>Stocks</span>
                </a>
                <a href="orders" class="menu-item" onclick="setActiveMenu('orders')">
                    <i data-lucide="shopping-cart" class="menu-icon"></i>
                    <span>Orders</span>
                </a>
                <a href="viewcustomer" class="menu-item" onclick="setActiveMenu('customers')">
                    <i data-lucide="users" class="menu-icon"></i>
                    <span>Customers</span>
                </a>
                <a href="viewsupplier" class="menu-item" onclick="setActiveMenu('suppliers')">
                    <i data-lucide="truck" class="menu-icon"></i>
                    <span>Suppliers</span>
                </a>
                <a href="viewcategory" class="menu-item" onclick="setActiveMenu('categories')">
                    <i data-lucide="folder" class="menu-icon"></i>
                    <span>Categories</span>
                </a>
                <a href="viewstockbalance" class="menu-item">
                    <i data-lucide="bar-chart-3" class="menu-icon"></i>
                    <span>Stock Balance</span>
                </a>
                <a href="viewwarehouse" class="menu-item" onclick="setActiveMenu('warehouse')">
                    <i data-lucide="warehouse" class="menu-icon"></i>
                    <span>Warehouse</span>
                </a>
                <a href="viewunit" class="menu-item" onclick="setActiveMenu('unit')">
				    <i data-lucide="scale" class="menu-icon"></i>
				    <span>Unit</span>
				</a>
                <a href="payments" class="menu-item" onclick="setActiveMenu('payments')">
                    <i data-lucide="credit-card" class="menu-icon"></i>
                    <span>Payments</span>
                </a>
                <a href="vouchers" class="menu-item" onclick="setActiveMenu('vouchers')">
                    <i data-lucide="file-text" class="menu-icon"></i>
                    <span>Vouchers</span>
                </a>
                
                <div class="logout-section">
                    <a href="logout" class="menu-item">
                        <i data-lucide="log-out" class="menu-icon"></i>
                        <span>Log Out</span>
                    </a>
                </div>
            </nav>
        </aside>
        <!-- Main Content -->
        <main class="main-content">
            <!-- Top Bar -->
            <div class="top-bar">
                <div class="search-container">
                    <i data-lucide="search" class="search-icon"></i>
                    <input type="text" class="search-input" placeholder="Search">
                </div>
                
                <div class="top-bar-actions">
                    <button class="action-btn">
                        <i data-lucide="bell"></i>
                        <span class="notification-dot"></span>
                    </button>
                    <button class="action-btn">
                        <i data-lucide="user"></i>
                    </button>
                </div>
            </div>
            <!-- Content Area -->
            <div class="content-area">
                <c:choose>
                    <c:when test="${not empty param.page}">
                        <jsp:include page="${param.page}.jsp" />
                    </c:when>
                    <c:otherwise>
                        <div class="content">
		    <div class="content-header d-flex justify-content-between align-items-center mb-4">
		        <h1 class="page-title">Stock List</h1>
		        <a href="stockform" class="btn btn-primary d-flex align-items-center">
		            <i data-lucide="plus" class="me-1"></i> Add New Stock
		        </a>
		    </div>
		
		    <div class="table-responsive">
		        <table class="table table-striped table-hover table-bordered">
		            <thead class="table-dark">
		                <tr>
		                    <th>ID</th>
		                    <th>Name</th>
		                    <th>Location</th>
		                    <th>Remark</th>
		                    <th>Method</th>
		                    <th>Category</th>
		                    <th>Unit</th>
		                    <th>Supplier</th>
		                    <th>Warehouse</th>
		                    <th>Edit</th>
		                    <th>Delete</th>
		                </tr>
		            </thead>
		            <tbody>
		                <c:forEach var="stock" items="${list}">
		                    <tr>
		                        <td>${stock.stockID}</td>
		                        <td>${stock.stockName}</td>
		                        <td>${stock.stockLocation}</td>
		                        <td>${stock.stockRemark}</td>
		                        <td>${stock.stockMethod}</td>
		                        <td>${stock.categoryID}</td>
		                        <td>${stock.unitID}</td>
		                        <td>${stock.supplierID}</td>
		                        <td>${stock.warehouseID}</td>
		                        <td>
		                            <a href="editstock/${stock.stockID}" class="btn btn-sm btn-warning">Edit</a>
		                        </td>
		                        <td>
		                            <a href="deletestock/${stock.stockID}" class="btn btn-sm btn-danger">Delete</a>
		                        </td>
		                    </tr>
		                </c:forEach>
		            </tbody>
		        </table>
		    </div>
		</div>
                    </c:otherwise>
                </c:choose>
            </div>
        </main>
    </div>

    <script src="https://unpkg.com/lucide@latest"></script>
    <script>
    // Initialize Lucide icons
    lucide.createIcons();
    
    let activeMenu = 'customers';

    function setActiveMenu(menuId) {
        // Remove active class from all menu items
        document.querySelectorAll('.menu-item').forEach(item => {
            item.classList.remove('active');
        });

        // Add active class to clicked item
        event.target.closest('.menu-item').classList.add('active');

        // Update active menu
        activeMenu = menuId;

        // Show/hide content
        const emptyState = document.getElementById('empty-state');
        const emptyTitle = document.getElementById('empty-title');

        // Check if the element exists
        if (emptyState && emptyTitle) {
            emptyState.style.display = menuId === 'customers' ? 'none' : 'block';
            emptyTitle.textContent = menuId.replace('-', ' ');
        }
    }

    // Add interactive effects
    document.addEventListener('DOMContentLoaded', function () {
        // Add click effects to buttons
        document.querySelectorAll('.add-btn, .action-btn').forEach(btn => {
            btn.addEventListener('click', function (e) {
                e.preventDefault();
                this.style.transform = 'scale(0.95)';
                setTimeout(() => {
                    this.style.transform = '';
                }, 150);
            });
        });

        // Search functionality placeholder
        const searchInput = document.querySelector('.search-input');
        if (searchInput) {
            searchInput.addEventListener('input', function () {
                console.log('Searching for:', this.value);
            });
        }
    });
</script>
</body> 
</html>
