<%@ page contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Ngwe Pone Gyi</title>
    <link href="https://unpkg.com/lucide@latest" rel="stylesheet">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
            background-color: #f5f5f5;
            color: #333;
            display: flex;
            flex-direction: column;
            min-height: 100vh;
        }

        /* Header */
        .header {
            background: #ff5722;
            color: white;
            height: 80px;
            display: flex;
            align-items: center;
            padding: 0 32px;
            position: fixed;
            width: 100%;
            z-index: 1000;
        }

        .header-content {
            display: flex;
            align-items: center;
            gap: 16px;
            width: 100%;
        }

        .logo {
            width: 56px;
            height: 56px;
            background: #e0e0e0;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            flex-shrink: 0;
        }
        
        .logo img {
            width: 40px;
            height: 40px;
            border-radius: 50%;
        }

        .brand-name {
            font-size: 35px;
            font-weight: 600;
            letter-spacing: 1px;
            margin-left: 600px;
        }

        /* Layout */
        .container {
            display: flex;
            flex: 1;
            margin-top: 80px;
        }

        /* Sidebar */
        .sidebar {
            width: 240px;
            background: white;
            border-right: 1px solid #e0e0e0;
            padding: 16px;
            position: fixed;
            top: 80px;
            bottom: 0;
            left: 0;
            overflow-y: auto;
            z-index: 900;
        }

        .nav-menu {
            display: flex;
            flex-direction: column;
            gap: 4px;
        }

        .menu-item {
            display: flex;
            align-items: center;
            gap: 12px;
            padding: 10px 16px;
            text-decoration: none;
            color: #666;
            font-size: 14px;
            font-weight: 500;
            transition: all 0.2s ease;
            cursor: pointer;
            border: none;
            background: none;
            width: 100%;
            text-align: left;
            border-radius: 8px;
        }

        .menu-item:hover {
            background-color: #f8f9fa;
            color: #333;
        }

        .menu-item.active {
            background-color: #e3f2fd;
            color: #1976d2;
            border: 1px solid #bbdefb;
        }

        .menu-icon {
            width: 20px;
            height: 20px;
            display: flex;
            align-items: center;
            justify-content: center;
        }

        .logout-section {
            border-top: 1px solid #e0e0e0;
            margin-top: auto;
            padding-top: 16px;
        }

        /* Main Content */
        .main-content {
            flex: 1;
            margin-left: 240px;
            background: #f8f9fa;
            min-height: calc(100vh - 80px);
            padding-bottom: 24px;
        }

        .top-bar {
            background: white;
            border-bottom: 1px solid #e0e0e0;
            padding: 16px 24px;
            display: flex;
            align-items: center;
            justify-content: space-between;
            margin-bottom: 24px;
        }

        .search-container {
            flex: 1;
            max-width: 400px;
            position: relative;
        }

        .search-input {
            width: 100%;
            padding: 10px 16px 10px 40px;
            border: 1px solid #ddd;
            border-radius: 8px;
            font-size: 14px;
            outline: none;
            transition: all 0.2s ease;
            background: #f8f9fa;
        }
        .search-input:focus {
            border-color: #1976d2;
            background: white;
            box-shadow: 0 0 0 3px rgba(25, 118, 210, 0.1);
        }

        .search-icon {
            position: absolute;
            left: 12px;
            top: 50%;
            transform: translateY(-50%);
            color: #999;
        }

        .top-bar-actions {
            display: flex;
            align-items: center;
            gap: 16px;
        }

        .action-btn {
            width: 40px;
            height: 40px;
            border: none;
            background: none;
            border-radius: 8px;
            display: flex;
            align-items: center;
            justify-content: center;
            color: #666;
            cursor: pointer;
            transition: all 0.2s ease;
            position: relative;
        }

        .action-btn:hover {
            background-color: #f0f0f0;
            color: #333;
        }

        .notification-dot {
            position: absolute;
            top: 8px;
            right: 8px;
            width: 8px;
            height: 8px;
            background: #f44336;
            border-radius: 50%;
        }

        /* Content Area */
        .content-area {
            background: white;
            border-radius: 8px;
            padding: 24px;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
            margin-left: 24px;
            margin-right: 24px;
        }

        /* Table Styles */
        .table-responsive {
            overflow-x: auto;
            margin-top: 20px;
            border-radius: 8px;
            border: 1px solid #e0e0e0;
        }

        .table {
            width: 100%;
            border-collapse: collapse;
            min-width: 600px;
        }

        .table th, .table td {
            padding: 12px 16px;
            text-align: left;
            border-bottom: 1px solid #e0e0e0;
        }

        .table th {
            background-color: #f8f9fa;
            color: #333;
            font-weight: 600;
            white-space: nowrap;
        }

        .table tr:last-child td {
            border-bottom: none;
        }

        .table-striped tbody tr:nth-of-type(odd) {
            background-color: rgba(0, 0, 0, 0.02);
        }

        .table-hover tbody tr:hover {
            background-color: rgba(0, 0, 0, 0.05);
        }

        /* Button Styling */
        .btn {
            padding: 10px 16px;
            border-radius: 4px;
            font-size: 14px;
            cursor: pointer;
            text-decoration: none;
            display: inline-block;
            transition: all 0.2s ease;
        }

        .btn-sm {
            padding: 8px 10px;
            font-size: 11px;
        }

        .btn-primary {
            background-color: #1976d2;
            color: white;
            border: none;
        }

        .btn-primary:hover {
            background-color: #1565c0;
        }

        .btn-warning {
            background-color: #ffc107;
            color: #212529;
            border: none;
        }

        .btn-warning:hover {
            background-color: #ffca2c;
        }

        .btn-danger {
            background-color: #dc3545;
            color: white;
            border: none;
        }

        .btn-danger:hover {
            background-color: #bb2d3b;
        }

        .btn-secondary {
            background-color: #6c757d;
            color: white;
            border: none;
        }

        .btn-secondary:hover {
            background-color: #5a6268;
        }

        /* Flex Utilities */
        .d-flex {
            display: flex;
        }

        .justify-content-between {
            justify-content: space-between;
        }

        .align-items-center {
            align-items: center;
        }

        .mb-4 {
            margin-bottom: 1.5rem;
        }

        /* Responsive */
        @media (max-width: 768px) {
            .container {
                flex-direction: column;
            }
            
            .sidebar {
                width: 100%;
                height: auto;
                position: relative;
                top: auto;
            }
            
            .main-content {
                margin-left: 0;
            }
        }
    </style>
</head>
<body>
    <!-- Header -->
    <header class="header">
        <div class="header-content">
            <div class="logo">
                <img src="data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 100 100'%3E%3Ccircle cx='50' cy='50' r='45' fill='%23ff5722'/%3E%3Ctext x='50' y='60' text-anchor='middle' fill='white' font-size='40' font-weight='bold'%3EN%3C/text%3E%3C/svg%3E" alt="Logo">
            </div>
            <h1 class="brand-name">Ngwe Pone Gyi</h1>
        </div>
    </header>

    <div class="container">
        <!-- Sidebar -->
        <aside class="sidebar">
            <nav class="nav-menu">
                <a href="dashboard" class="menu-item">
                    <i data-lucide="home" class="menu-icon"></i>
                    <span>Dashboard</span>
                </a>
                <a href="viewstock" class="menu-item">
                    <i data-lucide="package" class="menu-icon"></i>
                    <span>Stocks</span>
                </a>
                <a href="orders" class="menu-item">
                    <i data-lucide="shopping-cart" class="menu-icon"></i>
                    <span>Orders</span>
                </a>
                <a href="viewcustomer" class="menu-item">
                    <i data-lucide="users" class="menu-icon"></i>
                    <span>Customers</span>
                </a>
                <a href="viewsupplier" class="menu-item">
                    <i data-lucide="truck" class="menu-icon"></i>
                    <span>Suppliers</span>
                </a>
                <a href="viewcategory" class="menu-item">
                    <i data-lucide="folder" class="menu-icon"></i>
                    <span>Categories</span>
                </a>
                <a href="viewstockbalance" class="menu-item active">
                    <i data-lucide="bar-chart-3" class="menu-icon"></i>
                    <span>Stock Balance</span>
                </a>
                <a href="viewwarehouse" class="menu-item">
                    <i data-lucide="warehouse" class="menu-icon"></i>
                    <span>Warehouse</span>
                </a>
                <a href="viewunit" class="menu-item">
                    <i data-lucide="scale" class="menu-icon"></i>
                    <span>Unit</span>
                </a>
                <a href="payments" class="menu-item">
                    <i data-lucide="credit-card" class="menu-icon"></i>
                    <span>Payments</span>
                </a>
                <a href="vouchers" class="menu-item">
                    <i data-lucide="file-text" class="menu-icon"></i>
                    <span>Vouchers</span>
                </a>
                
                <div class="logout-section">
                    <a href="logout" class="menu-item">
                        <i data-lucide="log-out" class="menu-icon"></i>
                        <span>Log Out</span>
                    </a>
                </div>
            </nav>
        </aside>

        <!-- Main Content -->
        <main class="main-content">
            <!-- Top Bar -->
            <div class="top-bar">
                <div class="search-container">
                    <i data-lucide="search" class="search-icon"></i>
                    <input type="text" class="search-input" placeholder="Search">
                </div>
                
                <div class="top-bar-actions">
                    <button class="action-btn">
                        <i data-lucide="bell"></i>
                        <span class="notification-dot"></span>
                    </button>
                    <button class="action-btn">
                        <i data-lucide="user"></i>
                    </button>
                </div>
            </div>
            <!-- Content Area -->
            <div class="content-area">
			    <c:choose>
			        <c:when test="${not empty param.page}">
			            <jsp:include page="${param.page}.jsp" />
			        </c:when>
			        <c:otherwise>
			            <div class="content">
			                <div class="content-header d-flex justify-content-between align-items-center mb-4">
			                    <h1 class="page-title">Stock Balance</h1>
			                </div>
			
			                <div class="table-responsive">
			                    <table class="table table-striped table-hover">
			                        <thead>
			                            <tr>
			                                <th>Balance ID</th>
			                                <th>Stock ID</th>
			                                <th>Available Quantity</th>
			                                <th>Last Updated</th>
			                            </tr>
			                        </thead>
			                        <tbody>
			                            <c:forEach var="balance" items="${list}">
			                                <tr>
			                                    <td>${balance.balanceID}</td>
			                                    <td>${balance.stockID}</td>
			                                    <td>${balance.availableQty}</td>
			                                    <td>${balance.lastUpdated}</td>
			                                </tr>
			                            </c:forEach>
			                        </tbody>
			                    </table>
			                </div>
			            </div>
			        </c:otherwise>
			    </c:choose>
			</div>
        </main>
    </div>

    <script src="https://unpkg.com/lucide@latest"></script>
    <script>
    // Initialize Lucide icons
    lucide.createIcons();
    
    let activeMenu = 'unit';

    function setActiveMenu(menuId) {
        // Remove active class from all menu items
        document.querySelectorAll('.menu-item').forEach(item => {
            item.classList.remove('active');
        });

        // Add active class to clicked item
        event.target.closest('.menu-item').classList.add('active');

        // Update active menu
        activeMenu = menuId;
    }

    // Modal functions
    // Modal functions with enhanced animations
    function openModal(type, id, name, subUnit, remark) {
        const modal = type === 'add' ? 'addUnitModal' : 'editUnitModal';
        document.getElementById(modal).classList.add('active');
        document.body.style.overflow = 'hidden'; // Prevent scrolling
        
        if (type === 'edit') {
            document.getElementById('editUnitID').value = id;
            document.getElementById('editUnitName').value = name;
            document.getElementById('editSubUnit').value = subUnit || '';
            document.getElementById('editUnitRemark').value = remark || '';
        }
    }

    function closeModal(type) {
        const modal = type === 'add' ? 'addUnitModal' : 'editUnitModal';
        document.getElementById(modal).classList.remove('active');
        document.body.style.overflow = ''; // Re-enable scrolling
    }

    // Close modal when clicking outside or pressing ESC
    document.addEventListener('click', function(e) {
        if (e.target.classList.contains('modal-overlay')) {
            document.querySelectorAll('.modal-overlay').forEach(modal => {
                modal.classList.remove('active');
            });
            document.body.style.overflow = '';
        }
    });

    document.addEventListener('keydown', function(e) {
        if (e.key === 'Escape') {
            document.querySelectorAll('.modal-overlay').forEach(modal => {
                modal.classList.remove('active');
            });
            document.body.style.overflow = '';
        }
    });

    // Enhanced button hover effects
    document.addEventListener('DOMContentLoaded', function() {
        const buttons = document.querySelectorAll('.btn, .action-btn, .add-unit-btn');
        buttons.forEach(btn => {
            btn.addEventListener('mouseenter', function() {
                if (this.classList.contains('btn-primary')) {
                    this.style.transform = 'translateY(-2px)';
                }
            });
            btn.addEventListener('mouseleave', function() {
                if (this.classList.contains('btn-primary')) {
                    this.style.transform = 'translateY(0)';
                }
            });
        });
    });

    // Add interactive effects
    document.addEventListener('DOMContentLoaded', function () {
        // Add click effects to buttons
        document.querySelectorAll('.btn, .action-btn').forEach(btn => {
            btn.addEventListener('click', function (e) {
                if (!e.target.classList.contains('modal-close')) {
                    this.style.transform = 'scale(0.95)';
                    setTimeout(() => {
                        this.style.transform = '';
                    }, 150);
                }
            });
        });

        // Search functionality placeholder
        const searchInput = document.querySelector('.search-input');
        if (searchInput) {
            searchInput.addEventListener('input', function () {
                console.log('Searching for:', this.value);
            });
        }
    });
    </script>
</body>
</html>