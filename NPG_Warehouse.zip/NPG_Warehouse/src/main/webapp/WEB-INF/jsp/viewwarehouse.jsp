<%@ page contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Ngwe Pone Gyi</title>
    <link href="https://unpkg.com/lucide@latest" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

       body {
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
            background-color: #f5f5f5;
            color: #333;
            display: flex;
            flex-direction: column;
            min-height: 100vh;
        }

        /* Header */
        .header {
            background: #ff5722;
            color: white;
            height: 80px;
            display: flex;
            align-items: center;
            padding: 0 32px;
            position: sticky;
            top: 0;
            z-index: 1000;
            width: 100%;
            position: sticky;
		    top: 0;
		    z-index: 1000;
		    width: 100%;
        }

        .header-content {
            display: flex;
            align-items: center;
            gap: 16px;
            width: 100%;
        }

        .logo {
            width: 56px;
            height: 56px;
            background: #e0e0e0;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            flex-shrink: 0;
        }
        
        .logo img {
            width: 40px;
            height: 40px;
            border-radius: 50%;
        }

        .brand-name {
            font-size: 35px;
            font-weight: 600;
            letter-spacing: 1px;
            margin-left: auto;
            margin-right: auto;
        }

        /* Main container */
        .main-container {
		  display: flex;
		  flex: 1; /* ကျန်တဲ့နေရာအပြည့်ယူဖို့ */
		  overflow: hidden;
		}

        /* Sidebar */
        .sidebar {
            width: 240px;
            background: white;
            border-right: 1px solid #e0e0e0;
            padding: 16px;
            position: fixed;
            flex-shrink: 0;
            position: sticky;
            top: 80px;
            overflow-y: auto;
        }

        .nav-menu {
            display: flex;
            flex-direction: column;
            gap: 4px;
        }

        .menu-item {
            display: flex;
            align-items: center;
            gap: 12px;
            padding: 10px 16px;
            text-decoration: none;
            color: #666;
            font-size: 14px;
            font-weight: 500;
            transition: all 0.2s ease;
            cursor: pointer;
            border: none;
            background: none;
            width: 100%;
            text-align: left;
            border-radius: 8px;
        }

        .menu-item:hover {
            background-color: #f8f9fa;
            color: #333;
        }

        .menu-item.active {
            background-color: #e3f2fd;
            color: #1976d2;
            border: 1px solid #bbdefb;
        }

        .menu-icon {
            width: 20px;
            height: 20px;
            display: flex;
            align-items: center;
            justify-content: center;
        }

        .logout-section {
            border-top: 1px solid #e0e0e0;
            margin-top: 5px;
            padding-top: 16px;
        }

        /* Main Content */
        .main-content {
            flex: 1;
            display: flex;
            flex-direction: column;
            background: #f8f9fa;
            min-height: calc(100vh - 80px);
            overflow-y: auto;
        }

        /* Top Bar */
        .top-bar {
            background: white;
            border-bottom: 1px solid #e0e0e0;
            padding: 16px 24px;
            display: flex;
            align-items: center;
            justify-content: space-between;
            position: sticky;
            top: 0;
            z-index: 100;
        }

        .search-container {
            flex: 1;
            max-width: 400px;
            position: relative;
        }

        .search-input {
            width: 100%;
            padding: 10px 16px 10px 40px;
            border: 1px solid #ddd;
            border-radius: 8px;
            font-size: 14px;
            outline: none;
            transition: all 0.2s ease;
            background: #f8f9fa;
        }

        .search-input:focus {
            border-color: #1976d2;
            background: white;
            box-shadow: 0 0 0 3px rgba(25, 118, 210, 0.1);
        }

        .search-icon {
            position: absolute;
            left: 12px;
            top: 50%;
            transform: translateY(-50%);
            color: #999;
        }

        .top-bar-actions {
            display: flex;
            align-items: center;
            gap: 16px;
        }

        .action-btn {
            width: 40px;
            height: 40px;
            border: none;
            background: none;
            border-radius: 8px;
            display: flex;
            align-items: center;
            justify-content: center;
            color: #666;
            cursor: pointer;
            transition: all 0.2s ease;
            position: relative;
        }

        .action-btn:hover {
            background-color: #f0f0f0;
            color: #333;
        }

        .notification-dot {
            position: absolute;
            top: 8px;
            right: 8px;
            width: 8px;
            height: 8px;
            background: #f44336;
            border-radius: 50%;
        }

        /* Content Area */
        .content-area {
            padding: 24px;
            flex: 1;
        }

        .content-header {
            display: flex;
            align-items: center;
            justify-content: space-between;
            margin-bottom: 24px;
        }

        .page-title {
            font-size: 24px;
            font-weight: 600;
            color: #333;
        }

        .add-btn {
            display: flex;
            align-items: center;
            gap: 8px;
            background: #1976d2;
            color: white;
            border: none;
            padding: 10px 16px;
            border-radius: 8px;
            font-size: 14px;
            font-weight: 500;
            cursor: pointer;
            transition: all 0.2s ease;
        }

        .add-btn:hover {
            background: #1565c0;
        }

        .stat-row {
            display: flex;
            justify-content: space-between;
            font-size: 14px;
            margin-bottom: 4px;
        }

        .stat-value {
            font-weight: 600;
        }

        .text-green {
            color: #4caf50;
        }

        /* Empty State */
        .empty-state {
            text-align: center;
            padding: 40px 20px;
            color: #999;
        }

        .empty-icon {
            font-size: 48px;
            margin-bottom: 16px;
            opacity: 0.5;
        }

        .empty-title {
            font-size: 18px;
            font-weight: 600;
            color: #666;
            margin-bottom: 8px;
            text-transform: capitalize;
        }

        .empty-description {
            color: #999;
            font-size: 14px;
        }
        
        /* Warehouse Card Styles */
    .warehouse-list {
        display: grid;
        grid-template-columns: repeat(auto-fill, minmax(320px, 1fr));
        gap: 24px;
        margin-top: 24px;
    }
    
    .warehouse-card {
        background-color: white;
        border-radius: 12px;
        box-shadow: 0 4px 6px rgba(0, 0, 0, 0.05);
        padding: 24px;
        transition: all 0.3s ease;
        border: 1px solid #e9ecef;
        position: relative;
        overflow: hidden;
    }
    
    .warehouse-card:hover {
        transform: translateY(-4px);
        box-shadow: 0 10px 20px rgba(0, 0, 0, 0.1);
        border-color: #dee2e6;
    }
    
    .warehouse-card-header {
        display: flex;
        justify-content: space-between;
        align-items: flex-start;
        margin-bottom: 16px;
    }
    
    .warehouse-code {
        font-size: 14px;
        font-weight: 500;
        color: #6c757d;
        background: #f8f9fa;
        padding: 4px 8px;
        border-radius: 4px;
        display: inline-block;
    }
    
    .warehouse-status {
        font-size: 12px;
        font-weight: 600;
        padding: 4px 8px;
        border-radius: 12px;
        text-transform: uppercase;
    }
    
    .status-active {
        background-color: #e6f7ee;
        color: #28a745;
    }
    
    .status-inactive {
        background-color: #fce8e6;
        color: #dc3545;
    }
    
    .warehouse-name {
        font-size: 22px;
        font-weight: 700;
        color: #212529;
        margin-bottom: 12px;
        display: flex;
        align-items: center;
        gap: 8px;
    }
    
    .warehouse-icon {
        width: 24px;
        height: 24px;
        color: #0d6efd;
        background: #e7f1ff;
        border-radius: 6px;
        display: flex;
        align-items: center;
        justify-content: center;
        padding: 4px;
    }
    
    .warehouse-details {
        margin-bottom: 20px;
    }
    
    .detail-item {
        display: flex;
        align-items: flex-start;
        gap: 10px;
        margin-bottom: 10px;
        color: #495057;
        line-height: 1.5;
    }
    
    .detail-icon {
        flex-shrink: 0;
        color: #6c757d;
        width: 18px;
        height: 18px;
        margin-top: 2px;
    }
    
    .detail-text {
        flex: 1;
    }
    
    .detail-label {
        font-weight: 500;
        color: #343a40;
    }
    
    .divider {
        border-top: 1px solid #e9ecef;
        margin: 16px 0;
        opacity: 0.5;
    }
    
    .warehouse-actions {
        display: flex;
        gap: 12px;
        margin-top: 16px;
    }
    
    .action-btn {
        flex: 1;
        display: flex;
        align-items: center;
        justify-content: center;
        gap: 6px;
        padding: 8px 12px;
        border-radius: 6px;
        font-size: 14px;
        font-weight: 500;
        transition: all 0.2s ease;
    }
    
    .btn-edit {
        background-color: #f8f9fa;
        color: #0d6efd;
        border: 1px solid #dee2e6;
    }
    
    .btn-edit:hover {
        background-color: #e7f1ff;
        border-color: #cfe2ff;
    }
    
    .btn-delete {
        background-color: #f8f9fa;
        color: #dc3545;
        border: 1px solid #dee2e6;
    }
    
    .btn-delete:hover {
        background-color: #fce8e6;
        border-color: #f5c2c7;
    }
    
    .capacity-meter {
        margin-top: 16px;
    }
    
    .capacity-info {
        display: flex;
        justify-content: space-between;
        margin-bottom: 6px;
        font-size: 13px;
        color: #6c757d;
    }
    
    .capacity-bar {
        height: 6px;
        background: #e9ecef;
        border-radius: 3px;
        overflow: hidden;
    }
    
    .capacity-fill {
        height: 100%;
        background: linear-gradient(90deg, #4e73df, #224abe);
        border-radius: 3px;
        width: 65%; /* This should be dynamic based on actual capacity */
    }
    
    /* Modal styles */
        .modal-overlay {
            position: fixed;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background: rgba(0, 0, 0, 0.6);
            display: flex;
            align-items: center;
            justify-content: center;
            z-index: 1100;
            opacity: 0;
            visibility: hidden;
            transition: all 0.3s ease;
            backdrop-filter: blur(4px);
        }

        .modal-overlay.active {
            opacity: 1;
            visibility: visible;
        }

        .modal-content {
            background: white;
            border-radius: 12px;
            width: 500px;
            max-width: 90%;
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.2);
            transform: translateY(20px);
            transition: all 0.3s cubic-bezier(0.175, 0.885, 0.32, 1.275);
            overflow: hidden;
            border: none;
        }

        .modal-overlay.active .modal-content {
            transform: translateY(0);
        }

        .modal-header {
            padding: 18px 24px;
            background: linear-gradient(135deg, #ff5722 0%, #ff7043 100%);
            color: white;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .modal-title {
            font-size: 20px;
            font-weight: 600;
            letter-spacing: 0.5px;
        }

        .modal-close {
            background: rgba(255, 255, 255, 0.2);
            border: none;
            width: 32px;
            height: 32px;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            cursor: pointer;
            transition: all 0.2s ease;
        }

        .modal-close:hover {
            background: rgba(255, 255, 255, 0.3);
        }

        .modal-body {
            padding: 24px;
            background: #fafafa;
        }

        .modal-footer {
            padding: 16px 24px;
            background: white;
            border-top: 1px solid #f0f0f0;
            display: flex;
            justify-content: flex-end;
            gap: 12px;
        }

        /* Enhanced Form Styles */
        .form-group {
            margin-bottom: 20px;
        }

        .form-label {
            display: block;
            margin-bottom: 8px;
            font-weight: 500;
            color: #555;
            font-size: 14px;
        }

        .form-control {
            width: 100%;
            padding: 12px 16px;
            border: 1px solid #e0e0e0;
            border-radius: 8px;
            font-size: 14px;
            transition: all 0.2s ease;
            background: white;
            box-shadow: 0 1px 2px rgba(0, 0, 0, 0.05);
        }

        .form-control:focus {
            border-color: #ff5722;
            box-shadow: 0 0 0 3px rgba(255, 87, 34, 0.1);
            outline: none;
        }

        /* Enhanced Button Styles */
        .btn {
            padding: 10px 20px;
            border-radius: 8px;
            font-size: 14px;
            font-weight: 500;
            cursor: pointer;
            transition: all 0.2s ease;
            border: none;
            display: inline-flex;
            align-items: center;
            justify-content: center;
            gap: 8px;
        }

        .btn-secondary {
            background: #f5f5f5;
            color: #555;
        }

        .btn-secondary:hover {
            background: #e0e0e0;
        }

        .btn-primary {
            background: linear-gradient(135deg, #ff5722 0%, #ff7043 100%);
            color: white;
            box-shadow: 0 2px 6px rgba(255, 87, 34, 0.3);
        }

        .btn-primary:hover {
            background: linear-gradient(135deg, #e64a19 0%, #f4511e 100%);
            transform: translateY(-1px);
            box-shadow: 0 4px 8px rgba(255, 87, 34, 0.3);
        }
    
    /* Responsive adjustments */
    @media (max-width: 768px) {
        .warehouse-list {
            grid-template-columns: 1fr;
        }
        
        .warehouse-actions {
            flex-direction: column;
        }
    }
    </style>
</head>
<body>
    <!-- Header -->
    <header class="header">
        <div class="header-content">
            <div class="logo">
                <img src="data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 100 100'%3E%3Ccircle cx='50' cy='50' r='45' fill='%23ff5722'/%3E%3Ctext x='50' y='60' text-anchor='middle' fill='white' font-size='40' font-weight='bold'%3EN%3C/text%3E%3C/svg%3E" alt="Logo">
            </div>
            <h1 class="brand-name">Ngwe Pone Gyi</h1>
        </div>
    </header>

    <div class="main-container">
        <!-- Sidebar -->
        <aside class="sidebar">
            <nav class="nav-menu">
                <a href="dashboard" class="menu-item" onclick="setActiveMenu('dashboard')">
                    <i data-lucide="home" class="menu-icon"></i>
                    <span>Dashboard</span>
                </a>
                <a href="viewstock" class="menu-item" onclick="setActiveMenu('stocks')">
                    <i data-lucide="package" class="menu-icon"></i>
                    <span>Stocks</span>
                </a>
                <a href="orders" class="menu-item" onclick="setActiveMenu('orders')">
                    <i data-lucide="shopping-cart" class="menu-icon"></i>
                    <span>Orders</span>
                </a>
                <a href="viewcustomer" class="menu-item" onclick="setActiveMenu('customers')">
                    <i data-lucide="users" class="menu-icon"></i>
                    <span>Customers</span>
                </a>
                <a href="viewsupplier" class="menu-item" onclick="setActiveMenu('suppliers')">
                    <i data-lucide="truck" class="menu-icon"></i>
                    <span>Suppliers</span>
                </a>
                <a href="viewcategory" class="menu-item" onclick="setActiveMenu('categories')">
                    <i data-lucide="folder" class="menu-icon"></i>
                    <span>Categories</span>
                </a>
                <a href="viewstockbalance" class="menu-item" onclick="setActiveMenu('stock-balance')">
                    <i data-lucide="bar-chart-3" class="menu-icon"></i>
                    <span>Stock Balance</span>
                </a>
                <a href="viewwarehouse" class="menu-item active" onclick="setActiveMenu('warehouse')">
                    <i data-lucide="warehouse" class="menu-icon"></i>
                    <span>Warehouse</span>
                </a>
                <a href="viewunit" class="menu-item" onclick="setActiveMenu('unit')">
                    <i data-lucide="scale" class="menu-icon"></i>
                    <span>Unit</span>
                </a>
                <a href="payments" class="menu-item" onclick="setActiveMenu('payments')">
                    <i data-lucide="credit-card" class="menu-icon"></i>
                    <span>Payments</span>
                </a>
                <a href="vouchers" class="menu-item" onclick="setActiveMenu('vouchers')">
                    <i data-lucide="file-text" class="menu-icon"></i>
                    <span>Vouchers</span>
                </a>
                
                <div class="logout-section">
                    <a href="logout" class="menu-item">
                        <i data-lucide="log-out" class="menu-icon"></i>
                        <span>Log Out</span>
                    </a>
                </div>
            </nav>
        </aside>
    <!-- Content Area -->
    <div class="content-area">
        <c:choose>
            <c:when test="${not empty param.page}">
                <jsp:include page="${param.page}.jsp" />
            </c:when>
            <c:otherwise>
                <div class="content-area">
                    <div class="content-header d-flex justify-content-between align-items-center mb-4">
                        <h1 class="page-title">Warehouses</h1>
                        <button type="button" class="btn btn-primary d-flex align-items-center" onclick="openModal('add')">
                            <i data-lucide="plus" class="me-1"></i> Add Warehouse
                        </button>
                    </div>
    
                    <div class="warehouse-list">
                        <c:forEach var="warehouse" items="${list}">
                            <div class="warehouse-card">
                                <div class="warehouse-card-header">
                                    <span class="warehouse-code">WH-${warehouse.wareHouseID}</span>
                                    <span class="warehouse-status status-active">Active</span>
                                </div>
                                
                                <h3 class="warehouse-name">
                                    <span class="warehouse-icon">
                                        <i data-lucide="warehouse" width="16" height="16"></i>
                                    </span>
                                    ${warehouse.wareHouseName}
                                </h3>
                                
                                <div class="warehouse-details">
                                    <div class="detail-item">
                                        <i data-lucide="map-pin" class="detail-icon"></i>
                                        <div class="detail-text">
                                            <div class="detail-label">Address</div>
                                            ${warehouse.wareHouseAddress}
                                        </div>
                                    </div>
                                    
                                    <c:if test="${not empty warehouse.wareHouseLocation}">
                                    <div class="detail-item">
                                        <i data-lucide="navigation" class="detail-icon"></i>
                                        <div class="detail-text">
                                            <div class="detail-label">Location</div>
                                            ${warehouse.wareHouseLocation}
                                        </div>
                                    </div>
                                    </c:if>
                                    
                                    <div class="detail-item">
                                        <i data-lucide="info" class="detail-icon"></i>
                                        <div class="detail-text">
                                            <div class="detail-label">Details</div>
                                            <c:if test="${not empty warehouse.wareHouseLevel}">
                                                Level ${warehouse.wareHouseLevel}
                                            </c:if>
                                            <c:if test="${not empty warehouse.wareHouseLineNumber}">
                                                • Line ${warehouse.wareHouseLineNumber}
                                            </c:if>
                                        </div>
                                    </div>
                                </div>
                                
                                <div class="capacity-meter">
                                    <div class="capacity-info">
                                        <span>Capacity</span>
                                        <span>65% used</span>
                                    </div>
                                    <div class="capacity-bar">
                                        <div class="capacity-fill"></div>
                                    </div>
                                </div>
                                
                                <div class="divider"></div>
                                
                                <div class="warehouse-actions">
                                    <button type="button" class="action-btn btn-edit" 
                                        onclick="openModal('edit', '${warehouse.wareHouseID}', '${warehouse.wareHouseName}', 
                                        '${warehouse.wareHouseAddress}', '${warehouse.wareHouseLevel}', 
                                        '${warehouse.wareHouseLocation}', '${warehouse.wareHouseLineNumber}')">
                                        <i data-lucide="edit" width="14" height="14"></i>
                                        Edit
                                    </button>
                                    <a href="deletewarehouse/${warehouse.wareHouseID}" class="action-btn btn-delete">
                                        <i data-lucide="trash-2" width="14" height="14"></i>
                                        Delete
                                    </a>
                                </div>
                            </div>
                        </c:forEach>
                    </div>
                </div>
            </c:otherwise>
        </c:choose>
    </div>
    </div>

    <!-- Add Warehouse Modal -->
    <div id="addWarehouseModal" class="modal-overlay">
        <div class="modal-content">
            <form method="post" action="savewarehouse">
                <div class="modal-header">
                    <h5 class="modal-title">Add New Warehouse</h5>
                    <button type="button" class="modal-close" onclick="closeModal('add')">
                        <i data-lucide="x" width="18" height="18"></i>
                    </button>
                </div>
                <div class="modal-body">
                    <div class="form-group">
                        <label for="wareHouseID" class="form-label">Warehouse ID</label>
                        <input type="text" class="form-control" id="wareHouseID" name="wareHouseID" required>
                    </div>
                    <div class="form-group">
                        <label for="wareHouseName" class="form-label">Name</label>
                        <input type="text" class="form-control" id="wareHouseName" name="wareHouseName" required>
                    </div>
                    <div class="form-group">
                        <label for="wareHouseAddress" class="form-label">Address</label>
                        <input type="text" class="form-control" id="wareHouseAddress" name="wareHouseAddress" required>
                    </div>
                    <div class="form-group">
                        <label for="wareHouseLevel" class="form-label">Level</label>
                        <input type="text" class="form-control" id="wareHouseLevel" name="wareHouseLevel">
                    </div>
                    <div class="form-group">
                        <label for="wareHouseLocation" class="form-label">Location</label>
                        <input type="text" class="form-control" id="wareHouseLocation" name="wareHouseLocation">
                    </div>
                    <div class="form-group">
                        <label for="wareHouseLineNumber" class="form-label">Line Number</label>
                        <input type="text" class="form-control" id="wareHouseLineNumber" name="wareHouseLineNumber">
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" onclick="closeModal('add')">
                        <i data-lucide="x" class="me-1" width="16" height="16"></i> Cancel
                    </button>
                    <button type="submit" class="btn btn-primary">
                        <i data-lucide="save" class="me-1" width="16" height="16"></i> Save Warehouse
                    </button>
                </div>
            </form>
        </div>
    </div>

    <!-- Edit Warehouse Modal -->
    <div id="editWarehouseModal" class="modal-overlay">
        <div class="modal-content">
            <form method="post" action="editsavewarehouse">
                <div class="modal-header">
                    <h5 class="modal-title">Edit Warehouse</h5>
                    <button type="button" class="modal-close" onclick="closeModal('edit')">
                        <i data-lucide="x" width="18" height="18"></i>
                    </button>
                </div>
                <div class="modal-body">
                    <div class="form-group">
                        <label for="editWareHouseID" class="form-label">Warehouse ID</label>
                        <input type="text" class="form-control" id="editWareHouseID" name="wareHouseID" readonly>
                    </div>
                    <div class="form-group">
                        <label for="editWareHouseName" class="form-label">Name</label>
                        <input type="text" class="form-control" id="editWareHouseName" name="wareHouseName" required>
                    </div>
                    <div class="form-group">
                        <label for="editWareHouseAddress" class="form-label">Address</label>
                        <input type="text" class="form-control" id="editWareHouseAddress" name="wareHouseAddress" required>
                    </div>
                    <div class="form-group">
                        <label for="editWareHouseLevel" class="form-label">Level</label>
                        <input type="text" class="form-control" id="editWareHouseLevel" name="wareHouseLevel">
                    </div>
                    <div class="form-group">
                        <label for="editWareHouseLocation" class="form-label">Location</label>
                        <input type="text" class="form-control" id="editWareHouseLocation" name="wareHouseLocation">
                    </div>
                    <div class="form-group">
                        <label for="editWareHouseLineNumber" class="form-label">Line Number</label>
                        <input type="text" class="form-control" id="editWareHouseLineNumber" name="wareHouseLineNumber">
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" onclick="closeModal('edit')">
                        <i data-lucide="x" class="me-1" width="16" height="16"></i> Cancel
                    </button>
                    <button type="submit" class="btn btn-primary">
                        <i data-lucide="save" class="me-1" width="16" height="16"></i> Save Changes
                    </button>
                </div>
            </form>
        </div>
    </div>

    <script src="https://unpkg.com/lucide@latest"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        // Initialize Lucide icons
        lucide.createIcons();
        
        let activeMenu = 'warehouse';

        function setActiveMenu(menuId) {
            // Remove active class from all menu items
            document.querySelectorAll('.menu-item').forEach(item => {
                item.classList.remove('active');
            });

            // Add active class to clicked item
            event.target.closest('.menu-item').classList.add('active');

            // Update active menu
            activeMenu = menuId;
        }

        // Modal functions
        function openModal(type, id, name, address, level, location, lineNumber) {
            const modal = type === 'add' ? 'addWarehouseModal' : 'editWarehouseModal';
            document.getElementById(modal).classList.add('active');
            document.body.style.overflow = 'hidden';
            
            if (type === 'edit') {
                document.getElementById('editWareHouseID').value = id;
                document.getElementById('editWareHouseName').value = name;
                document.getElementById('editWareHouseAddress').value = address;
                document.getElementById('editWareHouseLevel').value = level || '';
                document.getElementById('editWareHouseLocation').value = location || '';
                document.getElementById('editWareHouseLineNumber').value = lineNumber || '';
            }
        }

        function closeModal(type) {
            const modal = type === 'add' ? 'addWarehouseModal' : 'editWarehouseModal';
            document.getElementById(modal).classList.remove('active');
            document.body.style.overflow = '';
        }

        // Close modal when clicking outside or pressing ESC
        document.addEventListener('click', function(e) {
            if (e.target.classList.contains('modal-overlay')) {
                document.querySelectorAll('.modal-overlay').forEach(modal => {
                    modal.classList.remove('active');
                });
                document.body.style.overflow = '';
            }
        });

        document.addEventListener('keydown', function(e) {
            if (e.key === 'Escape') {
                document.querySelectorAll('.modal-overlay').forEach(modal => {
                    modal.classList.remove('active');
                });
                document.body.style.overflow = '';
            }
        });

        // Add interactive effects
        document.addEventListener('DOMContentLoaded', function() {
            // Add click effects to buttons
            document.querySelectorAll('.btn, .action-btn').forEach(btn => {
                btn.addEventListener('click', function(e) {
                    if (!e.target.classList.contains('modal-close') && !this.hasAttribute('href')) {
                        this.style.transform = 'scale(0.95)';
                        setTimeout(() => {
                            this.style.transform = '';
                        }, 150);
                    }
                });
            });

            // Search functionality placeholder
            const searchInput = document.querySelector('.search-input');
            if (searchInput) {
                searchInput.addEventListener('input', function() {
                    console.log('Searching for:', this.value);
                });
            }
        });
    </script>
</body>
</html>