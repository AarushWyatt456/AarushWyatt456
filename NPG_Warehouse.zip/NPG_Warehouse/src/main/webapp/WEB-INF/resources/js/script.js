// Initialize the application when DOM is loaded
document.addEventListener('DOMContentLoaded', function() {
    // Initialize Lucide icons
    lucide.createIcons();
    
    // Set initial active menu
    let activeMenu = 'customers';
    updateActiveMenu(activeMenu);
    
    // Set up menu click handlers
    document.querySelectorAll('.menu-item').forEach(item => {
        item.addEventListener('click', function(e) {
            e.preventDefault();
            const menuId = this.getAttribute('data-menu-id') || 
                          this.getAttribute('onclick').match(/'([^']+)'/)[1];
            setActiveMenu(menuId);
        });
    });
    
    // Add interactive effects to buttons
    document.querySelectorAll('.add-btn, .action-btn').forEach(btn => {
        btn.addEventListener('click', function(e) {
            e.preventDefault();
            animateButtonClick(this);
        });
    });
    
    // Search functionality
    const searchInput = document.querySelector('.search-input');
    if (searchInput) {
        setupSearch(searchInput);
    }
    
    // Logout button handler
    const logoutBtn = document.querySelector('.logout-section .menu-item');
    if (logoutBtn) {
        logoutBtn.addEventListener('click', function(e) {
            e.preventDefault();
            confirmLogout();
        });
    }
    
    // Initialize any content that should be visible by default
    initializeContent();
});

// Set the active menu and update UI
function setActiveMenu(menuId) {
    // Remove active class from all menu items
    document.querySelectorAll('.menu-item').forEach(item => {
        item.classList.remove('active');
    });
    
    // Add active class to clicked item
    const activeItem = document.querySelector(`.menu-item[data-menu-id="${menuId}"]`) || 
                      document.querySelector(`.menu-item[onclick*="${menuId}"]`);
    if (activeItem) {
        activeItem.classList.add('active');
    }
    
    // Update active menu
    activeMenu = menuId;
    
    // Update content based on active menu
    updateContent(menuId);
    
    // Store in session for persistence
    sessionStorage.setItem('activeMenu', menuId);
}

// Update content based on active menu
function updateContent(menuId) {
    // Hide all content sections
    document.querySelectorAll('[data-content-section]').forEach(section => {
        section.style.display = 'none';
    });
    
    // Show the active content section
    const activeContent = document.querySelector(`[data-content-section="${menuId}"]`);
    if (activeContent) {
        activeContent.style.display = 'block';
        activeContent.classList.add('fade-in');
    } else {
        // Show empty state if no specific content exists
        const emptyState = document.getElementById('empty-state');
        const emptyTitle = document.getElementById('empty-title');
        
        if (emptyState && emptyTitle) {
            emptyState.style.display = 'block';
            emptyTitle.textContent = menuId.replace(/-/g, ' ');
            emptyState.classList.add('fade-in');
        }
    }
}

// Animate button click
function animateButtonClick(button) {
    button.style.transform = 'scale(0.95)';
    setTimeout(() => {
        button.style.transform = '';
    }, 150);
}

// Setup search functionality
function setupSearch(input) {
    let searchTimeout;
    
    input.addEventListener('input', function() {
        clearTimeout(searchTimeout);
        searchTimeout = setTimeout(() => {
            const searchTerm = this.value.trim();
            if (searchTerm.length > 0) {
                performSearch(searchTerm);
            }
        }, 300);
    });
    
    // Add clear button functionality
    const searchContainer = input.closest('.search-container');
    const clearBtn = document.createElement('button');
    clearBtn.innerHTML = '<i data-lucide="x"></i>';
    clearBtn.className = 'clear-btn';
    clearBtn.style.display = 'none';
    clearBtn.addEventListener('click', function() {
        input.value = '';
        this.style.display = 'none';
        performSearch('');
    });
    searchContainer.appendChild(clearBtn);
    lucide.createIcons();
    
    input.addEventListener('input', function() {
        clearBtn.style.display = this.value.length > 0 ? 'block' : 'none';
    });
}

// Perform search (placeholder - implement actual search logic)
function performSearch(term) {
    console.log('Searching for:', term);
    // Implement your actual search functionality here
    // This could make an AJAX call or filter local content
}

// Confirm logout
function confirmLogout() {
    if (confirm('Are you sure you want to log out?')) {
        // Implement logout functionality
        console.log('User logged out');
        // window.location.href = '/logout';
    }
}

// Initialize content
function initializeContent() {
    // Check for persisted active menu
    const persistedMenu = sessionStorage.getItem('activeMenu');
    if (persistedMenu) {
        setActiveMenu(persistedMenu);
    } else {
        setActiveMenu('customers');
    }
    
    // Initialize any other UI elements
    document.querySelector('.notification-dot').addEventListener('click', function() {
        alert('You have new notifications!');
    });
}

// Helper function to load content dynamically
function loadContent(url, targetElementId) {
    const target = document.getElementById(targetElementId);
    if (!target) return;
    
    target.innerHTML = '<div class="loading">Loading...</div>';
    
    fetch(url)
        .then(response => response.text())
        .then(html => {
            target.innerHTML = html;
            lucide.createIcons(); // Refresh icons for new content
        })
        .catch(error => {
            target.innerHTML = `<div class="error">Failed to load content: ${error.message}</div>`;
        });
}

// Expose functions to global scope if needed
window.setActiveMenu = setActiveMenu;
window.loadContent = loadContent;