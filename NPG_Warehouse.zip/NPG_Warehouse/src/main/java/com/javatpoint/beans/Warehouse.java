package com.javatpoint.beans;

public class Warehouse {
    private String wareHouseID;
    private String wareHouseName;
    private String wareHouseAddress;
    private String wareHouseLevel;
    private String wareHouseLocation;
    private String wareHouseLineNumber;

    // Getters and Setters
    public String getWareHouseID() {
        return wareHouseID;
    }

    public void setWareHouseID(String wareHouseID) {
        this.wareHouseID = wareHouseID;
    }

    public String getWareHouseName() {
        return wareHouseName;
    }

    public void setWareHouseName(String wareHouseName) {
        this.wareHouseName = wareHouseName;
    }

    public String getWareHouseAddress() {
        return wareHouseAddress;
    }

    public void setWareHouseAddress(String wareHouseAddress) {
        this.wareHouseAddress = wareHouseAddress;
    }

    public String getWareHouseLevel() {
        return wareHouseLevel;
    }

    public void setWareHouseLevel(String wareHouseLevel) {
        this.wareHouseLevel = wareHouseLevel;
    }

    public String getWareHouseLocation() {
        return wareHouseLocation;
    }

    public void setWareHouseLocation(String wareHouseLocation) {
        this.wareHouseLocation = wareHouseLocation;
    }

    public String getWareHouseLineNumber() {
        return wareHouseLineNumber;
    }

    public void setWareHouseLineNumber(String wareHouseLineNumber) {
        this.wareHouseLineNumber = wareHouseLineNumber;
    }
}