package com.javatpoint.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import com.javatpoint.beans.Customer;

public class CustomerDao {
    JdbcTemplate template;

    public void setTemplate(JdbcTemplate template) {
        this.template = template;
    }

    public int save(Customer c) {
        String sql = "insert into customer(CustomerID, CustomerName, CustomerPh, CustomerAddress) values('" + 
            c.getCustomerID() + "','" + c.getCustomerName() + "','" + 
            c.getCustomerPh() + "','" + c.getCustomerAddress() + "')";
        return template.update(sql);
    }

    public int update(Customer c) {
        String sql = "update customer set CustomerName='" + c.getCustomerName() + 
            "', CustomerPh='" + c.getCustomerPh() + 
            "', CustomerAddress='" + c.getCustomerAddress() + 
            "' where CustomerID='" + c.getCustomerID() + "'";
        return template.update(sql);
    }

    public int delete(String customerID) {
        String sql = "delete from customer where CustomerID='" + customerID + "'";
        return template.update(sql);
    }

    public Customer getCustomerById(String customerID) {
        String sql = "select * from customer where CustomerID=?";
        return template.queryForObject(sql, new Object[]{customerID}, new BeanPropertyRowMapper<Customer>(Customer.class));
    }

    public List<Customer> getCustomers() {
        return template.query("select * from customer", new RowMapper<Customer>() {
            public Customer mapRow(ResultSet rs, int row) throws SQLException {
                Customer c = new Customer();
                c.setCustomerID(rs.getString(1));
                c.setCustomerName(rs.getString(2));
                c.setCustomerPh(rs.getString(3));
                c.setCustomerAddress(rs.getString(4));
                return c;
            }
        });
    }
}