package com.javatpoint.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import com.javatpoint.beans.Supplier;

public class SupplierDao {
    JdbcTemplate template;

    public void setTemplate(JdbcTemplate template) {
        this.template = template;
    }

    public int save(Supplier s) {
        String sql = "INSERT INTO supplier(SupplierID, SupplierName, SupplierPh, SupplierAddress) " +
                     "VALUES('" + s.getSupplierID() + "','" + s.getSupplierName() + "','" + 
                     s.getSupplierPh() + "','" + s.getSupplierAddress() + "')";
        return template.update(sql);
    }

    public int update(Supplier s) {
        String sql = "UPDATE supplier SET SupplierName='" + s.getSupplierName() + 
                     "', SupplierPh='" + s.getSupplierPh() + 
                     "', SupplierAddress='" + s.getSupplierAddress() + 
                     "' WHERE SupplierID='" + s.getSupplierID() + "'";
        return template.update(sql);
    }

    public int delete(String supplierID) {
        String sql = "DELETE FROM supplier WHERE SupplierID='" + supplierID + "'";
        return template.update(sql);
    }

    public Supplier getSupplierById(String supplierID) {
        String sql = "SELECT * FROM supplier WHERE SupplierID=?";
        return template.queryForObject(sql, new Object[]{supplierID}, new BeanPropertyRowMapper<Supplier>(Supplier.class));
    }

    public List<Supplier> getSuppliers() {
        return template.query("SELECT * FROM supplier", new RowMapper<Supplier>() {
            public Supplier mapRow(ResultSet rs, int row) throws SQLException {
                Supplier s = new Supplier();
                s.setSupplierID(rs.getString("SupplierID"));
                s.setSupplierName(rs.getString("SupplierName"));
                s.setSupplierPh(rs.getString("SupplierPh"));
                s.setSupplierAddress(rs.getString("SupplierAddress"));
                return s;
            }
        });
    }
}