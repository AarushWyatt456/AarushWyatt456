package com.javatpoint.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import com.javatpoint.beans.StockBalance;

public class StockBalanceDao {
    JdbcTemplate template;

    public void setTemplate(JdbcTemplate template) {
        this.template = template;
    }

    public List<StockBalance> getStockBalances() {
        return template.query("SELECT * FROM stock_balance", new RowMapper<StockBalance>() {
            public StockBalance mapRow(ResultSet rs, int row) throws SQLException {
                StockBalance sb = new StockBalance();
                sb.setBalanceID(rs.getString("BalanceID"));
                sb.setStockID(rs.getString("StockID"));
                sb.setAvailableQty(rs.getInt("AvailableQty"));
                sb.setLastUpdated(rs.getDate("LastUpdated"));
                return sb;
            }
        });
    }

    public StockBalance getStockBalanceById(String balanceID) {
        String sql = "SELECT * FROM stock_balance WHERE BalanceID=?";
        return template.queryForObject(sql, new Object[]{balanceID}, new BeanPropertyRowMapper<StockBalance>(StockBalance.class));
    }
}