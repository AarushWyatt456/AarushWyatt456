package com.javatpoint.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import com.javatpoint.beans.Stock;

public class StockDao {
    JdbcTemplate template;

    public void setTemplate(JdbcTemplate template) {
        this.template = template;
    }

    public int save(Stock s) {
        String sql = "INSERT INTO stock(StockID, StockName, StockLocation, StockRemark, StockMethod, CategoryID, UnitID, SupplierID, WareHouseID) " +
                     "VALUES('" + s.getStockID() + "','" + s.getStockName() + "','" + 
                     s.getStockLocation() + "','" + s.getStockRemark() + "','" + 
                     s.getStockMethod() + "','" + s.getCategoryID() + "','" + 
                     s.getUnitID() + "','" + s.getSupplierID() + "','" + 
                     s.getWarehouseID() + "')";
        return template.update(sql);
    }

    public int update(Stock s) {
        String sql = "UPDATE stock SET StockName='" + s.getStockName() + 
                     "', StockLocation='" + s.getStockLocation() + 
                     "', StockRemark='" + s.getStockRemark() + 
                     "', StockMethod='" + s.getStockMethod() + 
                     "', CategoryID='" + s.getCategoryID() + 
                     "', UnitID='" + s.getUnitID() + 
                     "', SupplierID='" + s.getSupplierID() + 
                     "', WareHouseID='" + s.getWarehouseID() + 
                     "' WHERE StockID='" + s.getStockID() + "'";
        return template.update(sql);
    }

    public int delete(String stockID) {
        String sql = "DELETE FROM stock WHERE StockID='" + stockID + "'";
        return template.update(sql);
    }

    public Stock getStockById(String stockID) {
        String sql = "SELECT * FROM stock WHERE StockID=?";
        return template.queryForObject(sql, new Object[]{stockID}, new BeanPropertyRowMapper<Stock>(Stock.class));
    }

    public List<Stock> getStocks() {
        return template.query("SELECT * FROM stock", new RowMapper<Stock>() {
            public Stock mapRow(ResultSet rs, int row) throws SQLException {
                Stock s = new Stock();
                s.setStockID(rs.getString("StockID"));
                s.setStockName(rs.getString("StockName"));
                s.setStockLocation(rs.getString("StockLocation"));
                s.setStockRemark(rs.getString("StockRemark"));
                s.setStockMethod(rs.getString("StockMethod"));
                s.setCategoryID(rs.getString("CategoryID"));
                s.setUnitID(rs.getString("UnitID"));
                s.setSupplierID(rs.getString("SupplierID"));
                s.setWarehouseID(rs.getString("WareHouseID"));
                return s;
            }
        });
    }

    // Additional methods to get dropdown options
    public List<String> getCategories() {
        return template.query("SELECT CategoryID FROM category", new RowMapper<String>() {
            public String mapRow(ResultSet rs, int row) throws SQLException {
                return rs.getString("CategoryID");
            }
        });
    }

    public List<String> getUnits() {
        return template.query("SELECT UnitID FROM unit", new RowMapper<String>() {
            public String mapRow(ResultSet rs, int row) throws SQLException {
                return rs.getString("UnitID");
            }
        });
    }

    public List<String> getSuppliers() {
        return template.query("SELECT SupplierID FROM supplier", new RowMapper<String>() {
            public String mapRow(ResultSet rs, int row) throws SQLException {
                return rs.getString("SupplierID");
            }
        });
    }

    public List<String> getWarehouses() {
        return template.query("SELECT WareHouseID FROM warehouse", new RowMapper<String>() {
            public String mapRow(ResultSet rs, int row) throws SQLException {
                return rs.getString("WareHouseID");
            }
        });
    }
}