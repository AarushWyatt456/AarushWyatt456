package com.javatpoint.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import com.javatpoint.beans.Unit;

public class UnitDao {
    JdbcTemplate template;

    public void setTemplate(JdbcTemplate template) {
        this.template = template;
    }

    public int save(Unit u) {
        String sql = "INSERT INTO unit(UnitID, UnitName, SubUnit, UnitRemark) " +
                     "VALUES('" + u.getUnitID() + "','" + u.getUnitName() + "','" + 
                     u.getSubUnit() + "','" + u.getUnitRemark() + "')";
        return template.update(sql);
    }

    public int update(Unit u) {
        String sql = "UPDATE unit SET UnitName='" + u.getUnitName() + 
                     "', SubUnit='" + u.getSubUnit() + 
                     "', UnitRemark='" + u.getUnitRemark() + 
                     "' WHERE UnitID='" + u.getUnitID() + "'";
        return template.update(sql);
    }

    public int delete(String unitID) {
        String sql = "DELETE FROM unit WHERE UnitID='" + unitID + "'";
        return template.update(sql);
    }

    public Unit getUnitById(String unitID) {
        String sql = "SELECT * FROM unit WHERE UnitID=?";
        return template.queryForObject(sql, new Object[]{unitID}, new BeanPropertyRowMapper<Unit>(Unit.class));
    }

    public List<Unit> getUnits() {
        return template.query("SELECT * FROM unit", new RowMapper<Unit>() {
            public Unit mapRow(ResultSet rs, int row) throws SQLException {
                Unit u = new Unit();
                u.setUnitID(rs.getString("UnitID"));
                u.setUnitName(rs.getString("UnitName"));
                u.setSubUnit(rs.getString("SubUnit"));
                u.setUnitRemark(rs.getString("UnitRemark"));
                return u;
            }
        });
    }
}