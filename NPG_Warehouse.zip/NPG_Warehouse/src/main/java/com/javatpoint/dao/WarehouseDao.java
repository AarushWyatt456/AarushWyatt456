package com.javatpoint.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import com.javatpoint.beans.Warehouse;

public class WarehouseDao {
    JdbcTemplate template;

    public void setTemplate(JdbcTemplate template) {
        this.template = template;
    }

    public int save(Warehouse w) {
        String sql = "INSERT INTO warehouse(WareHouseID, WareHouseName, WareHouseAddress, " +
                     "WareHouseLevel, WareHouseLocation, WareHouseLineNumber) VALUES('" + 
                     w.getWareHouseID() + "','" + w.getWareHouseName() + "','" + 
                     w.getWareHouseAddress() + "','" + w.getWareHouseLevel() + "','" + 
                     w.getWareHouseLocation() + "','" + w.getWareHouseLineNumber() + "')";
        return template.update(sql);
    }

    public int update(Warehouse w) {
        String sql = "UPDATE warehouse SET WareHouseName='" + w.getWareHouseName() + 
                     "', WareHouseAddress='" + w.getWareHouseAddress() + 
                     "', WareHouseLevel='" + w.getWareHouseLevel() + 
                     "', WareHouseLocation='" + w.getWareHouseLocation() + 
                     "', WareHouseLineNumber='" + w.getWareHouseLineNumber() + 
                     "' WHERE WareHouseID='" + w.getWareHouseID() + "'";
        return template.update(sql);
    }

    public int delete(String wareHouseID) {
        String sql = "DELETE FROM warehouse WHERE WareHouseID='" + wareHouseID + "'";
        return template.update(sql);
    }

    public Warehouse getWarehouseById(String wareHouseID) {
        String sql = "SELECT * FROM warehouse WHERE WareHouseID=?";
        return template.queryForObject(sql, new Object[]{wareHouseID}, new BeanPropertyRowMapper<Warehouse>(Warehouse.class));
    }

    public List<Warehouse> getWarehouses() {
        return template.query("SELECT * FROM warehouse", new RowMapper<Warehouse>() {
            public Warehouse mapRow(ResultSet rs, int row) throws SQLException {
                Warehouse w = new Warehouse();
                w.setWareHouseID(rs.getString("WareHouseID"));
                w.setWareHouseName(rs.getString("WareHouseName"));
                w.setWareHouseAddress(rs.getString("WareHouseAddress"));
                w.setWareHouseLevel(rs.getString("WareHouseLevel"));
                w.setWareHouseLocation(rs.getString("WareHouseLocation"));
                w.setWareHouseLineNumber(rs.getString("WareHouseLineNumber"));
                return w;
            }
        });
    }
}