package com.javatpoint.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import com.javatpoint.beans.Category;

public class CategoryDao {
    JdbcTemplate template;

    public void setTemplate(JdbcTemplate template) {
        this.template = template;
    }

    public int save(Category c) {
        String sql = "insert into category(CategoryID, CategoryName, CategoryRemark) values('" + c.getCategoryID() + "','" + c.getCategoryName() + "','" + c.getCategoryRemark() + "')";
        return template.update(sql);
    }

    public int update(Category c) {
        String sql = "update category set CategoryName='" + c.getCategoryName() +
                "', CategoryRemark='" + c.getCategoryRemark() +
                "' where CategoryID='" + c.getCategoryID() + "'";
        return template.update(sql);
    }

    public int delete(String categoryID) {
        String sql = "delete from category where CategoryID='" + categoryID + "'";
        return template.update(sql);
    }

    public Category getCategoryById(String categoryID) {
        String sql = "select * from category where CategoryID=?";
        return template.queryForObject(sql, new Object[]{categoryID}, new BeanPropertyRowMapper<Category>(Category.class));
    }

    public List<Category> getCategories() {
        return template.query("select * from category", new RowMapper<Category>() {
            public Category mapRow(ResultSet rs, int row) throws SQLException {
                Category c = new Category();
                c.setCategoryID(rs.getString(1));
                c.setCategoryName(rs.getString(2));
                c.setCategoryRemark(rs.getString(3));
                return c;
            }
        });
    }
}