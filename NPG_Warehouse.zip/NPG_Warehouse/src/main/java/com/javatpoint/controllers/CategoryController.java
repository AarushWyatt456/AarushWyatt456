package com.javatpoint.controllers;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import com.javatpoint.beans.Category;
import com.javatpoint.dao.CategoryDao;

@Controller
public class CategoryController {
    @Autowired
    CategoryDao dao;

    @RequestMapping("/categoryform")
    public String showform(Model m) {
        m.addAttribute("command", new Category());
        return "categoryform";
    }

    @RequestMapping(value = "/savecategory", method = RequestMethod.POST)
    public String save(@ModelAttribute("category") Category category) {
        dao.save(category);
        return "redirect:/viewcategory";
    }

    @RequestMapping("/viewcategory")
    public String viewcategory(Model m) {
        List<Category> list = dao.getCategories();
        m.addAttribute("list", list);
        return "viewcategory";
    }

    @RequestMapping(value = "/editcategory/{categoryID}")
    public String edit(@PathVariable String categoryID, Model m) {
        Category category = dao.getCategoryById(categoryID);
        m.addAttribute("command", category);
        return "categoryeditform";
    }

    @RequestMapping(value = "/editsavecategory", method = RequestMethod.POST)
    public String editsave(@ModelAttribute("category") Category category) {
        dao.update(category);
        return "redirect:/viewcategory";
    }

    @RequestMapping(value = "/deletecategory/{categoryID}")
    public String delete(@PathVariable String categoryID) {
        dao.delete(categoryID);
        return "redirect:/viewcategory";
    }
}