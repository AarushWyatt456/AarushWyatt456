package com.javatpoint.controllers;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import com.javatpoint.beans.Warehouse;
import com.javatpoint.dao.WarehouseDao;

@Controller
public class WarehouseController {
    @Autowired
    WarehouseDao dao;

    @RequestMapping("/warehouseform")
    public String showform(Model m) {
        m.addAttribute("command", new Warehouse());
        return "warehouseform";
    }

    @RequestMapping(value = "/savewarehouse", method = RequestMethod.POST)
    public String save(@ModelAttribute("warehouse") Warehouse warehouse) {
        dao.save(warehouse);
        return "redirect:/viewwarehouse";
    }

    @RequestMapping("/viewwarehouse")
    public String viewwarehouse(Model m) {
        List<Warehouse> list = dao.getWarehouses();
        m.addAttribute("list", list);
        return "viewwarehouse";
    }

    @RequestMapping(value = "/editwarehouse/{wareHouseID}")
    public String edit(@PathVariable String wareHouseID, Model m) {
        Warehouse warehouse = dao.getWarehouseById(wareHouseID);
        m.addAttribute("command", warehouse);
        return "warehouseeditform";
    }

    @RequestMapping(value = "/editsavewarehouse", method = RequestMethod.POST)
    public String editsave(@ModelAttribute("warehouse") Warehouse warehouse) {
        dao.update(warehouse);
        return "redirect:/viewwarehouse";
    }

    @RequestMapping(value = "/deletewarehouse/{wareHouseID}")
    public String delete(@PathVariable String wareHouseID) {
        dao.delete(wareHouseID);
        return "redirect:/viewwarehouse";
    }
}