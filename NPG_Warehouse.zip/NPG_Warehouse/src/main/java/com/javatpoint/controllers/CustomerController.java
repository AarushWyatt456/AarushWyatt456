package com.javatpoint.controllers;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import com.javatpoint.beans.Customer;
import com.javatpoint.dao.CustomerDao;

@Controller
public class CustomerController {
    @Autowired
    CustomerDao dao;

    @RequestMapping("/customerform")
    public String showform(Model m) {
        m.addAttribute("command", new Customer());
        return "customerform";
    }

    @RequestMapping(value = "/savecustomer", method = RequestMethod.POST)
    public String save(@ModelAttribute("customer") Customer customer) {
        dao.save(customer);
        return "redirect:/viewcustomer";
    }

    @RequestMapping("/viewcustomer")
    public String viewcustomer(Model m) {
        List<Customer> list = dao.getCustomers();
        m.addAttribute("list", list);
        return "viewcustomer";
    }

    @RequestMapping(value = "/editcustomer/{customerID}")
    public String edit(@PathVariable String customerID, Model m) {
        Customer customer = dao.getCustomerById(customerID);
        m.addAttribute("command", customer);
        return "customereditform";
    }

    @RequestMapping(value = "/editsavecustomer", method = RequestMethod.POST)
    public String editsave(@ModelAttribute("customer") Customer customer) {
        dao.update(customer);
        return "redirect:/viewcustomer";
    }

    @RequestMapping(value = "/deletecustomer/{customerID}")
    public String delete(@PathVariable String customerID) {
        dao.delete(customerID);
        return "redirect:/viewcustomer";
    }
}