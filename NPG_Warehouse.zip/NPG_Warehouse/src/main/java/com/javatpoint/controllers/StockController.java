package com.javatpoint.controllers;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import com.javatpoint.beans.Stock;
import com.javatpoint.dao.StockDao;

@Controller
public class StockController {
    @Autowired
    StockDao dao;

    @RequestMapping("/stockform")
    public String showform(Model m) {
        m.addAttribute("command", new Stock());
        
        // Add dropdown options
        m.addAttribute("categories", dao.getCategories());
        m.addAttribute("units", dao.getUnits());
        m.addAttribute("suppliers", dao.getSuppliers());
        m.addAttribute("warehouses", dao.getWarehouses());
        
        return "stockform";
    }

    @RequestMapping(value = "/savestock", method = RequestMethod.POST)
    public String save(@ModelAttribute("stock") Stock stock) {
        dao.save(stock);
        return "redirect:/viewstock";
    }

    @RequestMapping("/viewstock")
    public String viewstock(Model m) {
        List<Stock> list = dao.getStocks();
        m.addAttribute("list", list);
        return "viewstock";
    }

    @RequestMapping(value = "/editstock/{stockID}")
    public String edit(@PathVariable String stockID, Model m) {
        Stock stock = dao.getStockById(stockID);
        m.addAttribute("command", stock);
        
        // Add dropdown options
        m.addAttribute("categories", dao.getCategories());
        m.addAttribute("units", dao.getUnits());
        m.addAttribute("suppliers", dao.getSuppliers());
        m.addAttribute("warehouses", dao.getWarehouses());
        
        return "stockeditform";
    }

    @RequestMapping(value = "/editsavestock", method = RequestMethod.POST)
    public String editsave(@ModelAttribute("stock") Stock stock) {
        dao.update(stock);
        return "redirect:/viewstock";
    }

    @RequestMapping(value = "/deletestock/{stockID}")
    public String delete(@PathVariable String stockID) {
        dao.delete(stockID);
        return "redirect:/viewstock";
    }
}