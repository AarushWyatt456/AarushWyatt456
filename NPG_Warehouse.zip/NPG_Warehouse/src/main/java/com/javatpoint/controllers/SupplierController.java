package com.javatpoint.controllers;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import com.javatpoint.beans.Supplier;
import com.javatpoint.dao.SupplierDao;

@Controller
public class SupplierController {
    @Autowired
    SupplierDao dao;

    @RequestMapping("/supplierform")
    public String showform(Model m) {
        m.addAttribute("command", new Supplier());
        return "supplierform";
    }

    @RequestMapping(value = "/savesupplier", method = RequestMethod.POST)
    public String save(@ModelAttribute("supplier") Supplier supplier) {
        dao.save(supplier);
        return "redirect:/viewsupplier";
    }

    @RequestMapping("/viewsupplier")
    public String viewsupplier(Model m) {
        List<Supplier> list = dao.getSuppliers();
        m.addAttribute("list", list);
        return "viewsupplier";
    }

    @RequestMapping(value = "/editsupplier/{supplierID}")
    public String edit(@PathVariable String supplierID, Model m) {
        Supplier supplier = dao.getSupplierById(supplierID);
        m.addAttribute("command", supplier);
        return "suppliereditform";
    }

    @RequestMapping(value = "/editsavesupplier", method = RequestMethod.POST)
    public String editsave(@ModelAttribute("supplier") Supplier supplier) {
        dao.update(supplier);
        return "redirect:/viewsupplier";
    }

    @RequestMapping(value = "/deletesupplier/{supplierID}")
    public String delete(@PathVariable String supplierID) {
        dao.delete(supplierID);
        return "redirect:/viewsupplier";
    }
}