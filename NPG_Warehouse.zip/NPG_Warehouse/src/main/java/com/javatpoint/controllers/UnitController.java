package com.javatpoint.controllers;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import com.javatpoint.beans.Unit;
import com.javatpoint.dao.UnitDao;

@Controller
public class UnitController {
    @Autowired
    UnitDao dao;

    @RequestMapping("/unitform")
    public String showform(Model m) {
        m.addAttribute("command", new Unit());
        return "unitform";
    }

    @RequestMapping(value = "/saveunit", method = RequestMethod.POST)
    public String save(@ModelAttribute("unit") Unit unit) {
        dao.save(unit);
        return "redirect:/viewunit";
    }

    @RequestMapping("/viewunit")
    public String viewunit(Model m) {
        List<Unit> list = dao.getUnits();
        m.addAttribute("list", list);
        return "viewunit";
    }

    @RequestMapping(value = "/editunit/{unitID}")
    public String edit(@PathVariable String unitID, Model m) {
        Unit unit = dao.getUnitById(unitID);
        m.addAttribute("command", unit);
        return "uniteditform";
    }

    @RequestMapping(value = "/editsaveunit", method = RequestMethod.POST)
    public String editsave(@ModelAttribute("unit") Unit unit) {
        dao.update(unit);
        return "redirect:/viewunit";
    }

    @RequestMapping(value = "/deleteunit/{unitID}")
    public String delete(@PathVariable String unitID) {
        dao.delete(unitID);
        return "redirect:/viewunit";
    }
}