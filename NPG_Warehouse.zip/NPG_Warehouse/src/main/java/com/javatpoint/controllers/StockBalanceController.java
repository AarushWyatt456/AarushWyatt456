package com.javatpoint.controllers;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import com.javatpoint.beans.StockBalance;
import com.javatpoint.dao.StockBalanceDao;

@Controller
public class StockBalanceController {
    @Autowired
    StockBalanceDao dao;

    @RequestMapping("/viewstockbalance")
    public String viewStockBalance(Model m) {
        List<StockBalance> list = dao.getStockBalances();
        m.addAttribute("list", list);
        return "viewstockbalance";
    }
}