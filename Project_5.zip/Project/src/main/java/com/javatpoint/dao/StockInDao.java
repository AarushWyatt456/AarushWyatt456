package com.javatpoint.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;

import com.javatpoint.beans.StockIn;


public class StockInDao {
    private JdbcTemplate template;

    public void setTemplate(JdbcTemplate template) {
        this.template = template;
    }

    public List<StockIn> getStockInsByPage(int pageid, int recordsPerPage) {
        int offset = (pageid - 1) * recordsPerPage;
        String sql = "SELECT si.*, s.StockName, sup.SupplierName " +
                     "FROM stock_in si " +
                     "LEFT JOIN stock s ON si.StockID = s.StockID " +
                     "LEFT JOIN supplier sup ON si.SupplierID = sup.SupplierID " +
                     "ORDER BY si.InID DESC LIMIT ? OFFSET ?";
        
        return template.query(sql, new Object[]{recordsPerPage, offset}, new RowMapper<StockIn>() {
            public StockIn mapRow(ResultSet rs, int row) throws SQLException {
                StockIn si = new StockIn();
                si.setInID(rs.getString("InID"));
                si.setStockID(rs.getString("StockID"));
                si.setStockName(rs.getString("StockName"));
                si.setQuantity(rs.getInt("Quantity"));
                si.setDateIn(rs.getDate("DateIn"));
                si.setSupplierID(rs.getString("SupplierID"));
                si.setSupplierName(rs.getString("SupplierName"));
                si.setWareHouseID(rs.getString("WareHouseID"));
                si.setRemarks(rs.getString("Remarks"));
                return si;
            }
        });
    }
 // Search stock ins with pagination
    public List<StockIn> searchStockIns(String query, int pageid, int recordsPerPage) {
        int offset = (pageid - 1) * recordsPerPage;
        String sql = "SELECT si.*, s.StockName, sup.SupplierName " +
                     "FROM stock_in si " +
                     "LEFT JOIN stock s ON si.StockID = s.StockID " +
                     "LEFT JOIN supplier sup ON si.SupplierID = sup.SupplierID " +
                     "WHERE si.InID LIKE ? OR " +
                     "si.StockID LIKE ? OR " +
                     "s.StockName LIKE ? OR " +
                     "si.Quantity LIKE ? OR " +
                     "si.DateIn LIKE ? OR " +
                     "si.SupplierID LIKE ? OR " +
                     "sup.SupplierName LIKE ? OR " +
                     "si.WareHouseID LIKE ? OR " +
                     "si.Remarks LIKE ? " +
                     "ORDER BY si.InID DESC LIMIT ? OFFSET ?";
        
        String searchQuery = "%" + query + "%";
        
        return template.query(sql, new Object[]{
            searchQuery, searchQuery, searchQuery, searchQuery,
            searchQuery, searchQuery, searchQuery, searchQuery,
            searchQuery, recordsPerPage, offset
        }, new RowMapper<StockIn>() {
            public StockIn mapRow(ResultSet rs, int row) throws SQLException {
                StockIn si = new StockIn();
                si.setInID(rs.getString("InID"));
                si.setStockID(rs.getString("StockID"));
                si.setStockName(rs.getString("StockName"));
                si.setQuantity(rs.getInt("Quantity"));
                si.setDateIn(rs.getDate("DateIn"));
                si.setSupplierID(rs.getString("SupplierID"));
                si.setSupplierName(rs.getString("SupplierName"));
                si.setWareHouseID(rs.getString("WareHouseID"));
                si.setRemarks(rs.getString("Remarks"));
                return si;
            }
        });
    }

    // Count search results
    /**
     * Counts search results for pagination
     * @param query Search term
     * @return Number of matching records
     */
    public int countSearchResults(String query) {
        String sql = "SELECT COUNT(*) FROM stock_in si " +
                     "LEFT JOIN stock s ON si.StockID = s.StockID " +
                     "LEFT JOIN supplier sup ON si.SupplierID = sup.SupplierID " +
                     "WHERE si.InID LIKE ? OR " +
                     "si.StockID LIKE ? OR " +
                     "s.StockName LIKE ? OR " +
                     "si.Quantity LIKE ? OR " +
                     "si.DateIn LIKE ? OR " +
                     "si.SupplierID LIKE ? OR " +
                     "sup.SupplierName LIKE ? OR " +
                     "si.WareHouseID LIKE ? OR " +
                     "si.Remarks LIKE ?";
        
        String searchQuery = "%" + query + "%";
        
        return template.queryForObject(sql, new Object[]{
            searchQuery, searchQuery, searchQuery, searchQuery,
            searchQuery, searchQuery, searchQuery, searchQuery,
            searchQuery
        }, Integer.class);
    }
    
    public int countStockIns() {
        String sql = "SELECT COUNT(*) FROM stock_in";
        return template.queryForObject(sql, Integer.class);
    }
}