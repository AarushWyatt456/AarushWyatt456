package com.javatpoint.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;

import com.javatpoint.beans.StockOut;

public class StockOutDao {
	private JdbcTemplate template;

	public void setTemplate(JdbcTemplate template) {
		this.template = template;
	}

	// Regular pagination
	 public List<StockOut> getStockOutsByPage(int pageid, int recordsPerPage) {
	        int offset = (pageid - 1) * recordsPerPage;
	        String sql = "SELECT so.*, s.StockName, c.CustomerName " +
	                     "FROM stock_out so " +
	                     "LEFT JOIN stock s ON so.StockID = s.StockID " +
	                     "LEFT JOIN customer c ON so.CustomerID = c.CustomerID " +
	                     "ORDER BY so.OUTID DESC, so.outID LIMIT ? OFFSET ?";
	        
	        return template.query(sql, new Object[]{recordsPerPage, offset}, new RowMapper<StockOut>() {
	            public StockOut mapRow(ResultSet rs, int row) throws SQLException {
	                StockOut so = new StockOut();
	                so.setOutID(rs.getString("OutID"));
	                so.setStockID(rs.getString("StockID"));
	                so.setStockName(rs.getString("StockName"));
	                so.setQuantity(rs.getInt("Quantity"));	               	                
	                so.setDateOut(rs.getDate("DateOut"));	                
	                so.setCustomerID(rs.getString("CustomerID"));
	                so.setCustomerName(rs.getString("CustomerName"));
	                so.setWareHouseID(rs.getString("WareHouseID"));
	                so.setRemarks(rs.getString("Remarks"));
	                return so;
	            }
	        });
	    }

	 /**
	     * Searches stock-out records with pagination and joined names
	     * @param query Search term
	     * @param pageid Current page number (1-based)
	     * @param recordsPerPage Number of records per page
	     * @return List of matching StockOut objects with additional name fields
	     */
	    public List<StockOut> searchStockOuts(String query, int pageid, int recordsPerPage) {
	        int offset = (pageid - 1) * recordsPerPage;
	        String sql = "SELECT so.*, s.StockName, c.CustomerName " +
	                     "FROM stock_out so " +
	                     "LEFT JOIN stock s ON so.StockID = s.StockID " +
	                     "LEFT JOIN customer c ON so.CustomerID = c.CustomerID " +
	                     "WHERE so.OutID LIKE ? OR " +
	                     "so.StockID LIKE ? OR " +
	                     "s.StockName LIKE ? OR " +
	                     "so.Quantity LIKE ? OR " +
	                     "so.DateOut LIKE ? OR " +
	                     "so.CustomerID LIKE ? OR " +
	                     "c.CustomerName LIKE ? OR " +
	                     "so.WareHouseID LIKE ? OR " +
	                     "so.Remarks LIKE ? " +
	                     "ORDER BY so.OUTID DESC, so.outID LIMIT ? OFFSET ?";
	        
	        String searchQuery = "%" + query + "%";
	        
	        return template.query(sql, new Object[]{
	            searchQuery, searchQuery, searchQuery, searchQuery,
	            searchQuery, searchQuery, searchQuery, searchQuery,
	            searchQuery, recordsPerPage, offset
	        }, new RowMapper<StockOut>() {
	            public StockOut mapRow(ResultSet rs, int row) throws SQLException {
	                StockOut so = new StockOut();
	                so.setOutID(rs.getString("OutID"));
	                so.setStockID(rs.getString("StockID"));
	                so.setStockName(rs.getString("StockName"));
	                so.setQuantity(rs.getInt("Quantity"));
	                so.setDateOut(rs.getDate("DateOut"));
	                so.setCustomerID(rs.getString("CustomerID"));
	                so.setCustomerName(rs.getString("CustomerName"));
	                so.setWareHouseID(rs.getString("WareHouseID"));
	                so.setRemarks(rs.getString("Remarks"));
	                return so;
	            }
	        });
	    }

	    /**
	     * Counts search results for pagination
	     * @param query Search term
	     * @return Number of matching records
	     */
	    public int countSearchResults(String query) {
	        String sql = "SELECT COUNT(*) FROM stock_out so " +
	                     "LEFT JOIN stock s ON so.StockID = s.StockID " +
	                     "LEFT JOIN customer c ON so.CustomerID = c.CustomerID " +
	                     "WHERE so.OutID LIKE ? OR " +
	                     "so.StockID LIKE ? OR " +
	                     "s.StockName LIKE ? OR " +
	                     "so.Quantity LIKE ? OR " +
	                     "so.DateOut LIKE ? OR " +
	                     "so.CustomerID LIKE ? OR " +
	                     "c.CustomerName LIKE ? OR " +
	                     "so.WareHouseID LIKE ? OR " +
	                     "so.Remarks LIKE ?";
	        
	        String searchQuery = "%" + query + "%";
	        
	        return template.queryForObject(sql, new Object[]{
	            searchQuery, searchQuery, searchQuery, searchQuery,
	            searchQuery, searchQuery, searchQuery, searchQuery,
	            searchQuery
	        }, Integer.class);
	    }
	    /**
	     * Counts total stock-out records
	     * @return Total number of stock-out records
	     */
	    public int countStockOuts() {
	        String sql = "SELECT COUNT(*) FROM stock_out";
	        return template.queryForObject(sql, Integer.class);
	    }
}