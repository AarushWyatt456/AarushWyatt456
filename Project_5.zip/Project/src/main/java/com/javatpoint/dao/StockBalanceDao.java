package com.javatpoint.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;

import com.javatpoint.beans.StockBalance;

public class StockBalanceDao {
    private JdbcTemplate template;

    public void setTemplate(JdbcTemplate template) {
        this.template = template;
    }

    // Regular pagination
    public List<StockBalance> getStockBalancesByPage(int pageid, int recordsPerPage) {
        int offset = (pageid - 1) * recordsPerPage;
        String sql = "SELECT sb.BalanceID, sb.StockID, sb.AvailableQty, sb.LastUpdated, s.StockName " +
                     "FROM stock_balance sb " +
                     "LEFT JOIN stock s ON sb.StockID = s.StockID " +
                     "ORDER BY sb.LastUpdated DESC, sb.BalanceID LIMIT ? OFFSET ?";
        
        return template.query(sql, new Object[]{recordsPerPage, offset}, new RowMapper<StockBalance>() {
            public StockBalance mapRow(ResultSet rs, int row) throws SQLException {
                StockBalance sb = new StockBalance();
                sb.setBalanceID(rs.getString("BalanceID"));
                sb.setStockID(rs.getString("StockID"));
                sb.setStockName(rs.getString("StockName"));
                sb.setAvailableQty(rs.getInt("AvailableQty"));
                sb.setLastUpdated(rs.getDate("LastUpdated"));
                return sb;
            }
        });
    }

    /**
     * Searches stock-balance records with pagination
     * @param query Search term
     * @param pageid Current page number (1-based)
     * @param recordsPerPage Number of records per page
     * @return List of matching StockBalance objects
     */
    public List<StockBalance> searchStockBalances(String query, int pageid, int recordsPerPage) {
        int offset = (pageid - 1) * recordsPerPage;
        String sql = "SELECT sb.BalanceID, sb.StockID, sb.AvailableQty, sb.LastUpdated, s.StockName " +
                     "FROM stock_balance sb " +
                     "LEFT JOIN stock s ON sb.StockID = s.StockID " +
                     "WHERE sb.BalanceID LIKE ? OR " +
                     "sb.StockID LIKE ? OR " +
                     "s.StockName LIKE ? OR " +
                     "sb.AvailableQty LIKE ? OR " +
                     "sb.LastUpdated LIKE ? " +
                     "ORDER BY sb.LastUpdated DESC, sb.BalanceID LIMIT ? OFFSET ?";
        
        String searchQuery = "%" + query + "%";
        
        return template.query(sql, new Object[]{
            searchQuery, searchQuery, searchQuery, searchQuery,
            searchQuery, recordsPerPage, offset
        }, new RowMapper<StockBalance>() {
            public StockBalance mapRow(ResultSet rs, int row) throws SQLException {
                StockBalance sb = new StockBalance();
                sb.setBalanceID(rs.getString("BalanceID"));
                sb.setStockID(rs.getString("StockID"));
                sb.setStockName(rs.getString("StockName"));
                sb.setAvailableQty(rs.getInt("AvailableQty"));
                sb.setLastUpdated(rs.getDate("LastUpdated"));
                return sb;
            }
        });
    }

    /**
     * Counts search results for pagination
     * @param query Search term
     * @return Number of matching records
     */
    public int countSearchResults(String query) {
        String sql = "SELECT COUNT(*) FROM stock_balance sb " +
                     "LEFT JOIN stock s ON sb.StockID = s.StockID " +
                     "WHERE sb.BalanceID LIKE ? OR " +
                     "sb.StockID LIKE ? OR " +
                     "s.StockName LIKE ? OR " +
                     "sb.AvailableQty LIKE ? OR " +
                     "sb.LastUpdated LIKE ?";
        
        String searchQuery = "%" + query + "%";
        
        return template.queryForObject(sql, new Object[]{
            searchQuery, searchQuery, searchQuery, searchQuery,
            searchQuery
        }, Integer.class);
    }

    /**
     * Counts total stock-balance records
     * @return Total number of stock-balance records
     */
    public int countStockBalances() {
        String sql = "SELECT COUNT(*) FROM stock_balance";
        return template.queryForObject(sql, Integer.class);
    }
}